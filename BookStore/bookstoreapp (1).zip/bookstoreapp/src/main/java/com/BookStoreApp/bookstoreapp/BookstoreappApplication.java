package com.BookStoreApp.bookstoreapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreappApplication.class, args);
	}

}
