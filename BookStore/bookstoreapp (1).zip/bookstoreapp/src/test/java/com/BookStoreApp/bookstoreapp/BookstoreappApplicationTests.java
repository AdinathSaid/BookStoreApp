package com.BookStoreApp.bookstoreapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreappApplicationTests {

	@Test
	void contextLoads() {
	}

}
